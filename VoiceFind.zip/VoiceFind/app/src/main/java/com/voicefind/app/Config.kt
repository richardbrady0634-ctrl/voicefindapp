package com.voicefind.app

import android.content.Context

/**
 * All tunable settings live here. Trigger phrases are matched using
 * "contains" against the lowercased text the recognizer returns, so
 * short, distinct phrases work best (avoid common words said in passing).
 */
object Config {

    private const val PREFS_NAME = "voicefind_prefs"
    private const val KEY_ALARM_PHRASE = "alarm_phrase"
    private const val KEY_LOCK_PHRASE = "lock_phrase"
    private const val KEY_SERVICE_ENABLED = "service_enabled"

    const val DEFAULT_ALARM_PHRASE = "find my phone"
    const val DEFAULT_LOCK_PHRASE = "lock now"

    fun getAlarmPhrase(context: Context): String =
        prefs(context).getString(KEY_ALARM_PHRASE, DEFAULT_ALARM_PHRASE) ?: DEFAULT_ALARM_PHRASE

    fun setAlarmPhrase(context: Context, phrase: String) {
        prefs(context).edit().putString(KEY_ALARM_PHRASE, phrase.lowercase().trim()).apply()
    }

    fun getLockPhrase(context: Context): String =
        prefs(context).getString(KEY_LOCK_PHRASE, DEFAULT_LOCK_PHRASE) ?: DEFAULT_LOCK_PHRASE

    fun setLockPhrase(context: Context, phrase: String) {
        prefs(context).edit().putString(KEY_LOCK_PHRASE, phrase.lowercase().trim()).apply()
    }

    fun isServiceEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SERVICE_ENABLED, false)

    fun setServiceEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_SERVICE_ENABLED, enabled).apply()
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
}
