package com.voicefind.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat

/**
 * Runs as a foreground service so the OS lets it keep the microphone open
 * even when the app is not in the foreground / the screen is locked.
 *
 * SpeechRecognizer sessions are short-lived, so this restarts listening
 * every time a result, error, or silence timeout ends a session -
 * creating a continuous loop.
 */
class VoiceListenerService : Service() {

    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isDestroyed = false

    companion object {
        private const val TAG = "VoiceListenerService"
        private const val CHANNEL_ID = "voicefind_listening"
        private const val NOTIFICATION_ID = 1001
        private const val RESTART_DELAY_MS = 400L
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        startListening()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // START_STICKY: ask the OS to recreate the service if it gets killed
        return START_STICKY
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        isDestroyed = true
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }

    private fun startListening() {
        if (isDestroyed) return

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    handleTranscript(results)
                    scheduleRestart()
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    // Check partials too, so triggers fire faster instead of
                    // waiting for the recognizer to decide it's done.
                    handleTranscript(partialResults)
                }

                override fun onError(error: Int) {
                    // Common during continuous use (e.g. ERROR_NO_MATCH, ERROR_SPEECH_TIMEOUT).
                    // Just restart - this is expected, not a real failure.
                    scheduleRestart()
                }

                override fun onEndOfSpeech() {
                    scheduleRestart()
                }

                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
            }

            try {
                startListening(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start listening, retrying", e)
                scheduleRestart()
            }
        }
    }

    private fun scheduleRestart() {
        if (isDestroyed) return
        handler.postDelayed({ startListening() }, RESTART_DELAY_MS)
    }

    private fun handleTranscript(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?: return
        val text = matches.joinToString(" ").lowercase().trim()
        if (text.isEmpty()) return

        val alarmPhrase = Config.getAlarmPhrase(this)
        val lockPhrase = Config.getLockPhrase(this)

        when {
            text.contains(lockPhrase) -> {
                // Check lock phrase first in case one phrase is a substring of the other
                Log.i(TAG, "Lock phrase detected")
                triggerLock()
            }
            text.contains(alarmPhrase) -> {
                Log.i(TAG, "Alarm phrase detected")
                triggerAlarm()
            }
        }
    }

    private fun triggerAlarm() {
        val intent = Intent(this, AlarmActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(intent)
    }

    private fun triggerLock() {
        LockAccessibilityService.requestLock()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "VoiceFind listening",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows while VoiceFind is listening for your trigger words"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): android.app.Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VoiceFind is listening")
            .setContentText("Say your trigger word to sound the alarm or lock the screen")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .build()
    }
}
