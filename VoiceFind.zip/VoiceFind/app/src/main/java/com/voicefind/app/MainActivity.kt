package com.voicefind.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.voicefind.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val requestPermissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.all { it }) {
            startListenerService()
        } else {
            binding.statusText.text = getString(R.string.status_permission_denied)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.alarmPhraseInput.setText(Config.getAlarmPhrase(this))
        binding.lockPhraseInput.setText(Config.getLockPhrase(this))

        binding.savePhrasesButton.setOnClickListener {
            val alarmPhrase = binding.alarmPhraseInput.text.toString().lowercase().trim()
            val lockPhrase = binding.lockPhraseInput.text.toString().lowercase().trim()
            if (alarmPhrase.isNotEmpty()) Config.setAlarmPhrase(this, alarmPhrase)
            if (lockPhrase.isNotEmpty()) Config.setLockPhrase(this, lockPhrase)
            binding.statusText.text = getString(R.string.status_phrases_saved)
        }

        binding.enableAccessibilityButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.startStopButton.setOnClickListener {
            if (Config.isServiceEnabled(this)) {
                stopListenerService()
            } else {
                requestPermissionsAndStart()
            }
        }

        updateUi()
    }

    override fun onResume() {
        super.onResume()
        updateUi()
    }

    private fun requestPermissionsAndStart() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isEmpty()) {
            startListenerService()
        } else {
            requestPermissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun startListenerService() {
        Config.setServiceEnabled(this, true)
        ContextCompat.startForegroundService(this, Intent(this, VoiceListenerService::class.java))
        updateUi()
    }

    private fun stopListenerService() {
        Config.setServiceEnabled(this, false)
        stopService(Intent(this, VoiceListenerService::class.java))
        updateUi()
    }

    private fun updateUi() {
        val running = Config.isServiceEnabled(this)
        binding.startStopButton.text = if (running) {
            getString(R.string.stop_listening)
        } else {
            getString(R.string.start_listening)
        }

        val accessibilityOn = isAccessibilityServiceEnabled()
        binding.accessibilityStatusText.text = if (accessibilityOn) {
            getString(R.string.accessibility_enabled)
        } else {
            getString(R.string.accessibility_disabled)
        }
    }

    /** Checks system settings directly rather than relying on the service's
     *  in-memory instance, since that won't survive a process restart. */
    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponent = "$packageName/${LockAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expectedComponent, ignoreCase = true)) return true
        }
        return false
    }
}
