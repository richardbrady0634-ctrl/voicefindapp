package com.voicefind.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Android requires either device-admin or an AccessibilityService to
 * programmatically lock the screen. This service does nothing except sit
 * ready to perform GLOBAL_ACTION_LOCK_SCREEN when asked.
 *
 * The user must manually enable this under
 * Settings > Accessibility > Downloaded apps > VoiceFind, since Android
 * does not allow silently requesting this permission.
 */
class LockAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        if (instance == this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed for our use case - we only use this service to
        // perform the lock-screen global action, not to observe events.
    }

    override fun onInterrupt() {}

    companion object {
        private var instance: LockAccessibilityService? = null

        val isEnabled: Boolean
            get() = instance != null

        fun requestLock() {
            instance?.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
    }
}
