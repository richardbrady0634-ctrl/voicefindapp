# VoiceFind

A voice-triggered "find my phone" app for Android. Say a trigger phrase and it
sounds a loud alarm (even from the lock screen); say a second phrase and it
instantly locks the screen.

## How it works

- **VoiceListenerService** runs as a foreground service (shows a persistent
  notification while active) and keeps Android's `SpeechRecognizer` running
  in a loop, since each recognition session only lasts a few seconds.
- Recognized speech is checked against two phrases you set in the app
  (defaults: **"find my phone"** for the alarm, **"lock now"** for the lock
  trigger).
- The alarm phrase launches **AlarmActivity**, a full-screen activity that
  can show over the lock screen, plays a looping alarm sound at max volume,
  and vibrates until you tap Stop.
- The lock phrase calls Android's `GLOBAL_ACTION_LOCK_SCREEN` via an
  **AccessibilityService** — this is the only public way for a non-system
  app to lock the screen programmatically.

## Before you build

You'll need **Android Studio** (free, from developer.android.com) installed
on your computer. Open this project folder directly in Android Studio and
let it sync Gradle — it will download everything it needs automatically.

1. Open Android Studio → **Open** → select the `VoiceFind` folder.
2. Wait for Gradle sync to finish.
3. Connect an Android phone (with USB debugging on) or use an emulator,
   then click **Run**.

## Setup on the phone after installing

1. Open the app, tap **Start Listening** — it'll ask for microphone and
   notification permissions.
2. Tap **Enable lock-screen permission** — this opens Android's
   Accessibility settings, where you need to manually turn on "VoiceFind."
   Android does not allow apps to request this permission any other way.
3. Try saying your alarm phrase and lock phrase to test.

## Important limitations to know about

- **Battery use**: continuous microphone listening is not light on battery.
  Expect noticeably faster drain, especially on older devices. You may want
  to mention this to users, or add a way to pause listening (e.g. only
  while charging).
- **Accuracy**: Android's built-in `SpeechRecognizer` needs a real internet
  connection for best accuracy on most devices, and can mishear phrases,
  especially in noisy environments. Short, distinctive phrases work best —
  avoid common words you might say in normal conversation, or it'll trigger
  by accident.
- **Manufacturer battery optimization**: Samsung, Xiaomi, Huawei, and others
  aggressively kill background services to save battery. Users likely need
  to manually exempt VoiceFind from battery optimization (Settings →
  Battery → unrestricted), or the listener will get killed after a while.
  Consider adding in-app instructions for this per-device, since it varies.
- **Google Play policy on the Accessibility permission**: Google requires
  apps requesting accessibility service access to clearly declare, in the
  Play Store listing, exactly why they need it, and the service is expected
  to only do what's declared. This app only uses it to trigger the lock
  action, which should be an easy policy fit, but you'll need to fill out
  the "Accessibility API" declaration form when submitting to Play Console.
- This app is **Android only**. iOS does not allow always-on background
  microphone listening or lock-screen wake-word triggers for third-party
  apps — only Siri has that system-level access.

## Customizing the trigger phrases

Users can change both phrases right in the app's main screen — they're
saved locally with `SharedPreferences` (see `Config.kt`). Matching is a
simple "contains" check against the lowercased transcript, not exact-match,
so phrases can be said with a little slack around them.

## Monetization notes (paid app / one-time purchase)

For a one-time-purchase app, you'd set the price directly in Google Play
Console when creating the store listing — no extra billing code needed in
the app itself, since there's nothing to unlock after purchase. If you ever
want a free trial + paid unlock model instead, that would require adding
Google Play Billing (a bigger addition) — happy to help with that later if
you go that route.
